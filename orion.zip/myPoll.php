<?
ini_set('display_errors', 0);
include"../../db/database.php";
?>
<html>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css">
<script src="https://code.jquery.com/jquery-2.2.3.min.js" defer></script>
<script src="./js/jquery-1.10.2.js"></script>
<script src="dist/js/bootstrap-checkbox.min.js" defer></script>

<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
  <!-- Include the jQuery Mobile library -->
  <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>

<style>
.alignleft {
	float: left;
}
.alignright {
	float: right;
}
.container {
  display: flex;
  justify-content: center;
}
.center {
  width: 800px;
}
</style>
</head>
<script>
function doSaveform(f){
	document.getElementById('sub').disabled=true;
	$(function(){
	l=0;
	for(i=1;i<=($('#numRows').val()-1);i++)
	{
		if($(".check"+i).is(':checked')==false)
		{
			l++;
		}

	}
	if(l>0)
	{
		document.getElementById('sub').disabled=false;
		alert('Please answer for all questions');
		return false;
	}
	else
	{
		document.getElementById('sub').disabled=true;
		f.action.value='save';
		f.submit();
	}
	});

}
</script>
<script>
$(document).ready(function() {

	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');

        vars.push(hash[0]);

        vars[i] = hash[1];
    }
	$('#userId').val(vars[0]);
	$('#userType').val(vars[1]);
	$('#flatId').val(vars[2]);
	$('#propertyId').val(vars[3]);
	window.localStorage.setItem("userId",vars[0]);
	window.localStorage.setItem("userType",vars[1]);
	window.localStorage.setItem("flatId",vars[2]);
	window.localStorage.setItem("propertyId",vars[3]);



for(i=1;i<=$('#numRows').val();i++)
	{
		$(".check"+i).click(function () {
			$('.'+$(this).attr('class')).not(this).prop('checked', false);	
		});
	}

});
	function homeMenu()
		{

		window.localStorage.clear();
		var url="dash.html?userId="+$('#userId').val()+"&userType="+$('#userType').val()+"&flatId="+$('#flatId').val()+"&propertyId="+$('#propertyId').val();
		$(location).attr('href',url);
		}

		function logout()
		{
//		var url="index.html";
		var url="login.html";
		$(location).attr('href',url);
		}
		


</script>
<body>
<div data-role="page" id="mainpage" >
	<div data-role="header" data-position="fixed">
	
	<h1>PPMS</h1>
	
	
	<a name="home-menu" id="home-menu" align="center" class="ui-btn ui-btn-inline ui-corner-all ui-icon-home ui-btn-icon-left ui-btn-header" onClick="homeMenu()"></a>
	<a name="logout" id="logout" class="ui-btn ui-icon-delete ui-btn-icon-left ui-btn-inline ui-corner-all ui-btn-header" onClick="logout()"></a>

	
	
	</div>

	<input type='hidden' name='userId' id='userId' value=''>
	<input type='hidden' name='userType' id='userType' value=''>
	<input type='hidden' name='flatId' id='flatId' value=''>
	<input type='hidden' name='propertyId' id='propertyId' value=''>
	
   

	<div id="wait" style="display:none;width:69px;height:89px;border:1px solid black;position:absolute;top:50%;left:50%;padding:2px;"><img src='images/busyindicator.gif' width="64" height="64" /><br>Loading..</div>


<?php
//$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$dbl= new O477( );
$sql = "select senturl from polling_url where custid='".$userId."' and custtype='".$userType."' and feedbacksent='N'";
$dbl->l478($sql);
$dbl->O478();
$actual_link=$dbl->l479('senturl');

$parts = explode("?",$actual_link);
$url =$parts[0]."?".base64_decode($parts[1]);
$query_str = parse_url($url, PHP_URL_QUERY);
parse_str($query_str, $query_params);
if($query_params['who']=='O')
{
$datail = OwnerDetail($query_params['userid']);
$custvalue=$query_params['userid'];
	$custid ='ownerid';
}
else if($query_params['who']=='T')
{
$datail = TenantDetail($query_params['userid']);
$custvalue=$query_params['userid'];
	$custid ='tenantid';
}

$dbl=new O477( );
$sql="select validfrom,validto from m_polls where noqid='".$query_params['pollid']."'";
$dbl->l478($sql);
$dbl->O478();

if(strtotime(date('Y-m-d')) >= strtotime($dbl->l479('validfrom')) && strtotime(date('Y-m-d')) <= strtotime($dbl->l479('validto')))
{
$dbs	= new O477( );
$qry1 = "select ".$custid." from t_poll where ".$custid."='".$custvalue."'  ";

$dbs->l478($qry1);

if($dbs->O47i() == 0)
{

if(!$action)
{
	?>
<form name='poll' id='poll' method='POST' enctype='multipart/form-data'><fieldset>
<legend align='center'>Pollingback</legend>
<table width = '90%' align='center'><tr><td align ='center'>
<img src='images/prestige.jpg' alt='no img'/></td></tr></table>

<table width = '90%' align='center'><tr><td>
<p>
Dear Owner/Tenant,<br><br>
Thank you for being associated with Prestige Property Manageent & Services. Our <b><i> OWNERS & TENANTS </b></i> are important to us and we work hard to everyone's satisfaction. Yourback is vital to improve the quality of customer service we commit to our customers. Please take a moment to complete theback form.<br><br><br>
Lt.Col. Sreekumar PM(Retd.)<br>
Sr.Vice President-Property Management</p></td></tr><table><br>



<table width = '90%' align='center'>
<tr>
<td width='15%'>Property<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 35%;' colspan='3'>&nbsp;&nbsp;<?=$query_params['property']?></td>

<td width='15%'>Name<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 35%;'>&nbsp;&nbsp;<?=$datail['name']?></td>
<tr>

<tr>
<td width='15%'>Flat/Unit No<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 35%;' colspan='3'>&nbsp;&nbsp;<?=Flatno($query_params['userid'],$query_params['who'])?></td>

<td width='15%'>Phone NO<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 40%;'>&nbsp;&nbsp;<?=$datail['mobileno']?></td>
<tr>


<?
$period=getPeriod($query_params['pollid']);
?>

<tr>
<td width='15%'>Period<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 16%;'>&nbsp;&nbsp;<?=$period['startdate']?></td>


<td width='3%'>To<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 16%;'>&nbsp;&nbsp;<?=$period['enddate']?></td>


<td width='15%'>Email ID<span class='alignright'>:</span></td>
<td style='border-width: 2px;border-bottom: 1px black solid;width: 40%;'>&nbsp;&nbsp;<?=$datail['email']?></td>
<tr>
</table><br>




<table width = '90%' align='center'>
<tr>
<td width='30%'>
</td>
<td width='15%' align='center'><b>Excellent</b>
</td>
<td width='15%' align='center'><b>Good</b>
</td> 
<td width='15%' align='center'><b>Satisfactory</b>
</td>
<td width='15%' align='center'><b>Unsatisfactory</b>
</td>
</tr>

<tr>
<td width='30%'>
</td>
<td width='15%'>
</td>
<td width='15%' colspan='2'>(Please tick your choice)
</td>
<td width='15%'>
</td>
</tr>
<?php
$dbl	= new O477( );
$sql="select * from m_multipoll_h a inner join m_polls b on a.id=b.noqid where a.id='".$query_params['pollid']."'";
$dbl->l478($sql);
$a=0;
while($dbl->O478())
{
	$pollname[$dbl->l479('pollid')]=$dbl->l479('question');
	$a++;
}
//$pollname = array('Security','House Keeping','Parking/Traffic Control','Lifts / Elevators','Electrical maintenance','Backup power','Landscape maintanance','Water supply','Behaviour of staff','Response to complaints');
$l=1;
foreach($pollname as $qid=>$pname)
	{
?><tr>
<td width='30%'><input type='hidden' name='questions<?=$l?>' id='questions<?=$l?>' value='<?=$qid?>'><?=$l?>.&nbsp; <?=$pname?>
</td>
<td width='15%' align='center'>
<input class='check<?=$l?>' type='checkbox' style="zoom:1.5" name='opt1<?=$l?>' id='opt1<?=$l?>' value='1'>
</td>
<td width='15%' align='center'>
<input class='check<?=$l?>' type='checkbox' style="zoom:1.5" name='opt2<?=$l?>' id='opt2<?=$l?>' value='1'>
</td>
<td width='15%' align='center'>
<input class='check<?=$l?>' type='checkbox' style="zoom:1.5" name='opt3<?=$l?>' id='opt3<?=$l?>' value='1'>
</td>
<td width='15%' align='center'>
<input class='check<?=$l?>' type='checkbox' style="zoom:1.5" name='opt4<?=$l?>' id='opt4<?=$l?>' value='1'>
</td>
</tr>
<?
	$l++;
	}
?>
<input type='hidden' name='numRows' id='numRows' value='<?=$l?>'> 
</table>

<table width = '90%' align='center'><tr>
<td><b>Suggestions for improvement:</b></td></tr>
<tr><td><p style='border-width: 2px;border-bottom: 1px black solid;' contenteditable='true' spellcheck="true"></p></td></tr>
<tr><td align ='right'></td></tr>

<tr><td>
<b><i>In case of any complaints or suggestions please email us: </i><a href=''>ppmscustomercare@prestigeconstructions.co.in</a></b>
</td></tr>

<tr><td><font size='2px'>
<b>Prestige Property Management & Services: </b>303,Copper Arch,#83,Infantry Road,Banglore-560001.Phone:91-80-255001397 Fax:91-80-25591945</font>
</td></tr>
<table>
<br><br><table align='center' name='sav' id='sav'>
<tr>
<td><input type='button' name='sub' id='sub' value='Submit'  class="btn btn-primary" onclick='doSaveform(poll);'></td>
</tr>
</table>
<input type='hidden' name='action' id='action' value='save'></fieldset>
</form>
<?
}
else if($action=='save')
{
$db	= new O477( );
$db1= new O477( );
if($query_params['who'] == 'O')
{
	$custvalue=$query_params['userid'];
	$custid ='ownerid';
}
if($query_params['who'] == 'T')
{
	$custvalue=$query_params['userid'];
	$custid ='tenantid';
}
/*$qry = "Insert into t_poll_h(ownerid,tenantid, propertyid, custtype) values ('".$ownerid."', '".$tenantid."','".$query_params['propertyid']."', '".$query_params['who']."')";
$db->l478($qry);*/
$qry = "Insert into t_poll (".$custid.", pollid, propertyid, custtype) values ('".$custvalue."', '".$query_params['pollid']."', '".$query_params['propertyid']."', '".$query_params['who']."')";
$db->l478($qry);
$lastid = $db->l47s( );  
for($i=1;$i<$numRows;$i++)
{
$option1 = "opt1".$i;
$option2 = "opt2".$i;
$option3 = "opt3".$i;
$option4 = "opt4".$i;
$questions="questions".$i;

$qry = "Insert into t_poll_d(h_id,custid,custtype,option1,option2,option3,option4,questions) values ('".$lastid."','".$custvalue."','".$query_params['who']."','".$$option1."', '".$$option2."','".$$option3."', '".$$option4."','".$$questions."')";
$db->l478($qry);

$qry = "update m_polldet set optionvalue = optionvalue+1 where pollid='".$query_params['pollid']."' and propertyid= '".$query_params['propertyid']."' and optionname='".$pollname[$i]."'";
$db->l478($qry);
	if($query_params['who'] == 'O')
	{
		$sql="update polling_url set feedbacksent='Y' where custid='".$query_params['userid']."' and pollid='".$query_params['pollid']."'";
	}
	if($query_params['who'] == 'T')
	{
		$sql="update polling_url set feedbacksent='Y' where custid='".$query_params['userid']."' and pollid='".$query_params['pollid']."'";
	}
	$db->l478($sql);
}





?>
<br><br><br><br>
<div class='container'>
<div class="alert alert-success center" align='center' id='divElement'>
  <strong>Thanks for Feedback!</strong>
</div></div>
<?
}
}
else{
?>
<br><br><br><br>
<div class='container'>
<div class="alert alert-success center" align='center' id='divElement'>
  <strong>Feedback already Submitted...</strong>
</div></div>
<?

}
}
else
{
	?>
	<br><br><br><br>
	<div class='container'>
	<div class="alert alert-success center" align='center' id='divElement'>
	<strong>Link Expired</strong>
	</div></div><?
}
?>
	<div data-role="footer" data-position="fixed">
	<p align='center'><font size="2"><span  style="cursor:pointer">&copy; 2017 Phoenix Login Solutions Pvt Ltd.</span></p>
	</div>

</div>
</body></html>


<?php



function dmy2($d    ) {
         if (empty($d)) return "";
         $_xx=explode("-",$d);
        return $_xx[2]."-".$_xx[1]."-".$_xx[0];
 }

function getPeriod($id){

$dbl2	= new O477( );
$sql2="select * from m_multipoll_h a inner join m_polls b on a.id=b.noqid where a.id='".$id."'";
$dbl2->l478($sql2);
//echo "124-->".$sql2;

$dbl2->O478();
//echo "<br>vcv->";

	$period['startdate']=dmy2($dbl2->l479('startdate'));
	$period['enddate']=dmy2($dbl2->l479('enddate'));
	
	//print_r($period);


	return $period;

}


function OwnerDetail($id)
{
$db=new O477(    )  ;
$sqlQuery = "select * from m_ownerdetail where ownerid='".$id."'";
$db->l478($sqlQuery);
$db->O478();
$arr['name']=$db->l479("firstname");
$arr['mobileno']=$db->l479("Tel");
$arr['email']=$db->l479("Email1");
return $arr;
}

function TenantDetail($id)
{
$db=new O477( );
$sqlQuery = "select * from m_tenantdetail where tenantid='".$id."'";
$db->l478($sqlQuery);
$db->O478();
$arr['name']=$db->l479("firstname");
$arr['mobileno']=$db->l479("City");
$arr['email']=$db->l479("Email");
return $arr;
}

function Flatno($id,$custtype)
{
$db=new O477(    )  ;
if($custtype=='O')
{
	$sql = "select f.flatno,f.flatid,f.blockid,blockname from  m_flat f left join m_block d on f.blockid=d.blockid left join m_ownerdetail_d o on f.flatid = o.flatid where 1 and ( ownerid='".$id."' or f.flag <>'Y') group by f.flatid order by f.flatid ";
}
else if($custtype=='T')
{
	$sql = "select f.flatno,f.flatid,f.blockid from  m_flat f left join m_tenantdetail_d d on f.flatid=d.flatid and d.status!='0' left join m_ownerdetail_d o on f.flatid = o.flatid where 1 and d.status!='0' and ( tenantid='".$id."' or tenantflag <> 'Y') and o.occupied ='T'  group by f.flatid order by f.flatid ";
}
$db->l478($sql);
$db->O478();
return $db->l479("flatno");
}
?>