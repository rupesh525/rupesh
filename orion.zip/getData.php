<?php
include("../db/database.php");
if($id == "getappstudent")
{
	$db = new database();

	$db->query("SELECT a.studid, b.studid, a.firstname,b.gcm_regid
FROM m_studetail a
INNER JOIN gcm_users b
ON a.studid=b.studid where a.classid='".$classids."' and a.secid='".$secids."' group by b.studid ");

	$selectOptions="<option value='0'>Choose Student</option>";
	$selec="";
	while($db->read())
	{
		if($db->f("studid") && strlen($db->f("gcm_regid"))>1)
		{
		$selectOptions .= "<option value='".$db->f("studid")."' ".$selec.">".$db->f("firstname")." </option>";
		}
	}
	echo $selectOptions;

}


if($id == 'getclasslist')
{
	/*$dbc = new database();
	//$dbc->query("select * from m_classes where recflag='L' and courcatid='1'");
		$dbc->query("select classid,classcode,classname from m_classes where recflag='L' and courseid='1' and classid in(select classid from m_assignsubjects where teacherid='".$staffid."' order by classid ) order by classid asc");
	while($dbc->read())
	{
			$clasid = $dbc->f("classid");
            $clsname= $dbc->f("classname");
	$data[]=array(
		'clasid' => $clasid,
		'clsname'=> $clsname
		);
	}
echo json_encode($data);*/

	$db = new database();
	$db1 = new database();
	//$sql="select classid from m_users where user_id='".$staffid."'";
	$sql="select * from m_assigTeacher where teacherid='".$staffid."' and recflag='L' group by classid,sectionid";
	$db1->query($sql);
	while($db1->read())
	{
		$data[]=array(
		'classid' => $db1->f('classid'),
		'clasid'  => classcode($db1->f('classid')),
		'clsname' => classname($db1->f('classid')),
		'secid'	  => $db1->f('sectionid'),
		'secname' => getsecname($db1->f('sectionid'))
		);
		header('Content-type:application/json');
	}

	/*$classids = $db1->f('classid');
	if($classids !=0)
	{
	$classid=explode(',',$classids);
		foreach($classid as $id)
		{
			$data[]=array(
			'classid' => $id,
			'clasid'  => classcode($id),
			'clsname' => classname($id),
			'secid'	  => trim(substr(sections_($id,'id'),0,-1)),
			'secname' => substr(sections_($id,'name'),0,-1)
			);
			header('Content-type:application/json');
		}
	}*/

	echo json_encode($data);

}

if($id == "loadff")
{
	$db = new database();

	$db->query("SELECT * FROM m_notifitemplate where smsid='".$tempid."' ");
	while($db->read())
	{
	$f1 = $db->f('f1');
	$f2 = $db->f('f2');
	$f3 = $db->f('f3');
	$f4 = $db->f('f4');
	$f5 = $db->f('f5');
	$f6 = $db->f('f6');
	$f1charallow = $db->f('f1charallow');
	$f2charallow = $db->f('f2charallow');
	$f3charallow = $db->f('f3charallow');
	$f4charallow = $db->f('f4charallow');
	$f5charallow = $db->f('f5charallow');
	$f6charallow = $db->f('f6charallow');
	$cf1 = $db->f('cf1');
	$cf2 = $db->f('cf2');
	$cf3 = $db->f('cf3');
	$cf4 = $db->f('cf4');
	$cf5 = $db->f('cf5');
	$cf6 = $db->f('cf6');
	$templatemess = $db->f('message');
	$subject = $db->f('subject');
	}
	$data[]=array(
		'f1' => $f1,
		'f2' => $f2,
		'f3' => $f3,
		'f4' => $f4,
		'f5' => $f5,
		'f6' => $f6,
		'f1charallow' => $f1charallow,
		'f2charallow' => $f2charallow,
		'f3charallow' => $f3charallow,
		'f4charallow' => $f4charallow,
		'f5charallow' => $f5charallow,
		'f6charallow' => $f6charallow,
		'cf1'=> $cf1,
		'cf2'=> $cf2,
		'cf3'=> $cf3,
		'cf4'=> $cf4,
		'cf5'=> $cf5,
		'cf6'=> $cf6,
		'message' => $templatemess,
		'subject' => $subject
		);
	echo json_encode($data);

}


if($id == "loadtemplate")
{
	$db = new database();

	$db->query("SELECT smsid,templatename FROM m_notifitemplate where 1 and status='1' ");
	$selectOptions="<option value='0'>Choose Template</option>";
	$selec="";
	while($db->read())
	{
		$selectOptions .= "<option value='".$db->f("smsid")."' ".$selec.">".$db->f("templatename")." </option>";
	}
	echo $selectOptions;

}


function classcode($id)
{
	$dv = new database();
	$sql = "select classcode from m_classes where classid='".$id."'";
	$dv->query($sql);
	while($dv->read())
	{
		return $dv->f('classcode');
	}
}

function classname($id)
{
	$dv = new database();
	$sql = "select classname from m_classes where classid='".$id."'";
	$dv->query($sql);
	while($dv->read())
	{
		return $dv->f('classname');
	}
}

function sections_($cid,$f)
{
	$db=new database();
	$sql = "select b.secid,b.secname from m_classections a left join m_sections b on a.secid=b.secid join user_classsec c on a.classid=c.classid and a.secid=c.secid where a.classid='".$cid."' order by b.secid";
	$db->query($sql);
	while($db->read())
	{
		if($f == 'id')
		{
			$data.=$db->f('secid').',';
		}
		elseif($f == 'name')
		{
			$data.=$db->f('secname').',';
		}
	}
	return $data;
}

function getsecname($sel){
	$db = new database();
	$db->query("select secname from m_sections where secid='".$sel."'");

	$db->read();
	return $db->f("secname");
}
?>