/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
function loadXMLDoc(p1)
{
  var device_model=document.getElementById('device_model').value ;
  var device_cordova=document.getElementById('device_cordova').value ;    
  var device_platform=document.getElementById('device_platform').value;    
  var device_uuid=  document.getElementById('device_uuid').value;       
  var device_version=document.getElementById('device_version').value;

var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
  //  document.getElementById("myDiv").innerHTML=xmlhttp.responseText;

     var res = xmlhttp.responseText.split("-");
   // alert(res[0]+'='+res[1]);
    if(xmlhttp.responseText != 0)
    {
    
     if(res[1] == 'S')
      {
      //window.location.href="dash.html?id="+res[0]+"&type="+res[1]+"&regid="+p1;
      //window.location.href="dash.html?id="+res[0]+"&type="+res[1]+"&regid="+p1;
      window.location.href="dash.html?id="+res[0]+"&type="+res[1]+"&regid="+p1;
      }
      else
      {
      window.location.href="index.html";
      }
    }
    
   
        
    }
  }
  var name = "http://customer-phoenixlogin.com/pramati/admin/mapp/modules/check.php?device_uuid="+device_uuid;
//alert(name);
xmlhttp.open("GET",name,true);
xmlhttp.send();
}

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
        var pushNotification = window.plugins.pushNotification;
pushNotification.register(app.successHandler, app.errorHandler,{"senderID":"456567610447","ecb":"app.onNotificationGCM"});
    },
    // result contains any message sent from the plugin call
successHandler: function(result) {
    //alert('Callback Success! Result = '+result)
},
errorHandler:function(error) {
    alert(error);
},
onNotificationGCM: function(e) {
        switch( e.event )
        {
            case 'registered':
                if ( e.regid.length > 0 )
                {
                    console.log("Regid " + e.regid);
                    document.getElementById('reg1').value=e.regid;
                    loadXMLDoc(e.regid);
                  // alert('registration id = '+e.regid);

                }
            break;
 
            case 'message':
              // this is the actual push notification. its format depends on the data model from the push server
              //alert(e.message);

            break;
 
            case 'error':
              alert('GCM error = '+e.msg);
            break;
 
            default:
              alert('An unknown GCM event has occurred');
              break;
        }
    }
};

app.initialize();